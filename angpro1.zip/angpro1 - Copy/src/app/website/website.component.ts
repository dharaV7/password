import { Component, OnInit } from '@angular/core';
import { Observable, debounceTime, distinctUntilChanged, map } from 'rxjs';
import { PasswordManagerService } from '../password-manager.service';
import { MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';

@Component({
  selector: 'app-website',
  templateUrl: './website.component.html',
  styleUrl: './website.component.css'
})
export class WebsiteComponent implements OnInit {
  
  siteName!: string;
  siteURL!: string;
  siteImgURL!: string;
  siteId!: string;
  formState: string ="Add New";

  siteToDelete: any;

  isSuccess:boolean = false;
  successMessage!:string;

  allSites!: Observable<Array<any>>;
  filteredSites!: Observable<Array<any>>;

  searchQuery: string = '';

  isMatchFound: boolean = true; // Add this property

  ngOnInit() {
    // Initialize filteredSites with the original list
    this.filteredSites = this.allSites;
  }

  showAlert(message:string){
    this.isSuccess=true;
    this.successMessage=message;
  }

  confirmDelete(site: any) {
    this.siteToDelete = site;
    if (confirm(`Are you sure you want to delete ${site.siteName}?`)) {
      this.deleteSite(site.id);
    }
  }

  searchSite() {
  if (this.searchQuery) {
    this.filteredSites = this.allSites.pipe(
      debounceTime(300),
      distinctUntilChanged(),
      map(sites => {
        const filtered = sites.filter(site => site.siteName.toLowerCase().includes(this.searchQuery.toLowerCase()));

        // Sorting logic here
        return filtered.sort((a, b) => {
          const aStartsWithQuery = a.siteName.toLowerCase().startsWith(this.searchQuery.toLowerCase()) ? -1 : 1;
          const bStartsWithQuery = b.siteName.toLowerCase().startsWith(this.searchQuery.toLowerCase()) ? -1 : 1;

          return aStartsWithQuery - bStartsWithQuery;
        });
      })
    );
  } else {
    this.filteredSites = this.allSites;
  }
}


getMatchingCharactersCount(siteName: string): number {
  let count = 0;
  const searchQueryLower = this.searchQuery.toLowerCase();

  for (let i = 0; i < siteName.length; i++) {
    if (siteName.toLowerCase().charAt(i) === searchQueryLower.charAt(i)) {
      count++;
    } else {
      break;
    }
  }

  return count;
}

  

  // Update the dismissNoMatch method
  dismissNoMatch() {
    this.isMatchFound = true;
    this.searchQuery = '';
    this.filteredSites = this.allSites;
  }

  constructor(private passwordManagerService: PasswordManagerService, private router: Router){
    this.loadSites();
  }
  loadSites() {
    this.allSites = this.passwordManagerService.loadSites();
  }


  editSite(siteName: string, siteURL: string, siteImgURL:string, id:string){
    this.siteName=siteName;
    this.siteURL=siteURL;
    this.siteImgURL=siteImgURL;
    this.siteId=id;
    this.formState = "Edit";

    this.router.navigate(['/site-list'], {
      queryParams: {
        siteId: this.siteId,
        siteName: this.siteName,
        siteURL: this.siteURL,
        siteImgURL: this.siteImgURL,
        formState: this.formState
      }
    });
  }

  deleteSite(id: string){
    this.passwordManagerService.deleteSite(id)
    .then(()=>{
      this.showAlert('Data deleted successfully');
    })
    .catch(err=>{
      console.log(err);
    })
  }
}
