import { Component, ElementRef, HostListener, OnInit} from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { LogoutConfirmationComponent } from '../logout-confirmation/logout-confirmation.component';
import { Router } from '@angular/router';
import { PasswordManagerService } from '../password-manager.service';
import { User } from 'firebase/auth';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css']
})
export class NavbarComponent implements OnInit {

  user: User | null = null;
  userEmail: string | null = null;

  constructor(private dialog: MatDialog, private router:Router, private elementRef: ElementRef, private passwordManagerService: PasswordManagerService){}

  ngOnInit(): void {
    this.passwordManagerService.getCurrentUser().then((user) => {
      this.user = user;

      if (user) {
        this.passwordManagerService.getUserEmail().then((email) => {
          this.userEmail = email;
        });
      }
    });
  }

  openLogoutConfirmation(): void {
    const dialogRef = this.dialog.open(LogoutConfirmationComponent);

    dialogRef.afterClosed().subscribe((result) => {
      // Check the result to determine if the user confirmed logout
      if (result === true) {
        setTimeout(() => {
          this.router.navigate(['/']);
        }, 1000);
      } else {
        // User clicked "No" or closed the dialog
      }
    });
  }

  @HostListener('document:click', ['$event'])
  clickOutsideDropdown(event: Event) {
    if (!this.elementRef.nativeElement.contains(event.target)) {
      this.isDropdownOpen = false;
    }
  }
  showProfileDropdown: boolean = false;

  isDropdownOpen = false;

  toggleDropdown() {
    this.isDropdownOpen = !this.isDropdownOpen;
  }
  
}
