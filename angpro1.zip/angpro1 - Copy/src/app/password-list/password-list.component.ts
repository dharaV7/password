import { Component } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { PasswordManagerService } from '../password-manager.service';
import { Observable } from 'rxjs';

import { AES, enc } from 'crypto-js';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-password-list',
  templateUrl: './password-list.component.html',
  styleUrls: ['./password-list.component.css']
})
export class PasswordListComponent {

  siteId!:string;
  siteName!:string;
  siteURL!:string;
  siteImgURL!:string;

  passwordList!:Array<any>;

  email!: string;
  username!: string;
  password!: string;
  passwordId!: string;

  formState: string = 'Add New';

  isSuccess: boolean=false;
  successMessage!:string;

  constructor(private route: ActivatedRoute, private passwordManagerService: PasswordManagerService){
    this.route.queryParams.subscribe((val:any)=>{
      this.siteId=val.id;
      this.siteName=val.siteName;
      this.siteURL=val.siteURL;
      this.siteImgURL=val.siteImgURL;
     })

     this.loadPasswords();

  }

  showAlert(message:string){
    this.isSuccess=true;
    this.successMessage=message;
  }
  
  dismissSuccessMessage() {
    this.isSuccess = false;
  }


  resetForm(){
    this.email='';
    this.username='';
    this.password='';
    this.formState='Add New';
    this.passwordId='';
  }

  
  onSubmit(values:any){
    
    const encryptedPassword = this.encryptPassword(values.password);
    values.password = encryptedPassword;

    if(this.formState=='Add New'){
      this.passwordManagerService.addPassword(values, this.siteId)
    .then(()=>{
      console.log('Password saved successfully');
      this.showAlert('Data saved successfully');
      this.resetForm();
    })
    .catch(err=>{
      console.log(err);
    })
    }
    else if(this.formState=='Edit'){
      this.passwordManagerService.updatePassword(this.siteId, this.passwordId, values)
      .then(()=>{
        console.log('Data updated');
        this.showAlert('Data updated successfully');
        this.resetForm();
      })
      .catch(err=>{
        console.log(err);
      })
    }
  }

  loadPasswords(){
    this.passwordManagerService.loadPasswords(this.siteId).subscribe(val=>{
      this.passwordList =val;
    });
  }

  editPassword(email: string, username: string, password: string, passwordId: string){
    this.email = email;
    this.username = username;
    this.password = password;
    this.passwordId = passwordId;

    this.formState = 'Edit';
  }

  deletePassword(passwordId: string){
    this.passwordManagerService.deletePassword(this.siteId, passwordId)
    .then(()=>{
      console.log('Data deleted');
      this.showAlert('Data deleted successfully');
    })
    .catch(err=>{
      console.log(err);
      
    })
  }

  encryptPassword(password:string){
    const secretKey='pIlxd09wD1mDemok8ON3iOMhZ24THuwi';
    const encryptedPassword = AES.encrypt(password, secretKey).toString();
    return encryptedPassword;
  }

  decryptPassword(password: string){
    const secretKey='pIlxd09wD1mDemok8ON3iOMhZ24THuwi';
    const decryptedPassword = AES.decrypt(password, secretKey).toString(enc.Utf8);
    return decryptedPassword;
  }

  onDecrypt(password: string, index:number){
    const decryptedPassword = this.decryptPassword(password);
    this.passwordList[index].password = decryptedPassword;
  }
}
