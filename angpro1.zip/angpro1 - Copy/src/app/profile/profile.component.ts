import { Component, OnInit } from '@angular/core';
import { PasswordManagerService } from '../password-manager.service';
import { User } from 'firebase/auth';
import { Router } from '@angular/router';
import { doc, getDoc } from 'firebase/firestore';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {
  [x: string]: any;

  userName: string | null = 'Username';
  user: User | null = null;
  userEmail: string | null = null;
  newEmail: string = '';
  newPassword: string = '';
  isSuccess: boolean = false;
  alertType: 'success' | 'error' = 'success';
  successMessage: string = '';
  userId!:string;
  editMode = false; 
  editedUserName: string | null = ''; 
  private isInitialized = false;

  constructor(private passwordManagerService: PasswordManagerService, private router: Router) {}

  showAlert(message:string, type: 'success' | 'error' = 'success'){
    this.isSuccess=true;
    this.successMessage=message;
    this.alertType = type;
  }

  ngOnInit(): void {
    if (!this.isInitialized) {
      this.initProfileData();
      this.isInitialized = true;
    }
    this.passwordManagerService.getCurrentUser().then((user) => {
      this.user = user;

      if (user) {
        this.passwordManagerService.getUserEmail().then((email) => {
          this.userEmail = email;
        });
      }
    });
  }

  dismissSuccessMessage(): void {
    this.isSuccess = false;
  }

  resetForm(){
    this.newEmail='';
    this.newPassword='';
  }

  changeEmail() {
    this.passwordManagerService.changeEmail(this.newEmail)
      .then(() => {
        this.showAlert('Email changed successfully.Redirecting to Login...', 'success');
        this.resetForm();
        setTimeout(() => {
          this.router.navigate(['/']);
        }, 3000);
      })
      .catch((error) => {
        this.showAlert('Error changing email: ' + error.message, 'error');
      });
  }

  changePassword() {
    this.passwordManagerService.changePassword(this.newPassword)
      .then(() => {
        this.showAlert('Password changed successfully.Redirecting to Login...', 'success');
        this.resetForm();
        setTimeout(() => {
          this.router.navigate(['/']);
        }, 3000);
      })
      .catch((error) => {
        this.showAlert('Error changing password: ' + error.message, 'error');
      });
  }
  enableEditMode() {
    this.editedUserName = this.userName || ''; // Set edited username to current username
    this.editMode = true;
  }
  
  saveUserName() {
  if (this.editedUserName) {
    this.passwordManagerService.updateUsername(this.editedUserName)
      .then(() => {
        this.userName = this.editedUserName;
        this.editMode = false;
        this.showAlert('Username changed successfully.', 'success');
      })
      .catch((error) => {
        this.showAlert('Error changing username: ' + error.message, 'error');
      });
  }
}


  private initProfileData(): void {
    // Load user data and set editedUserName
    this.passwordManagerService.getCurrentUser()
      .then((user) => {
        if (user) {
          this.editedUserName = user.displayName || 'Guest';
          // Other profile data loading logic
        }
      })
      .catch((error) => {
        console.error('Error loading user data:', error);
      });
  }

}
