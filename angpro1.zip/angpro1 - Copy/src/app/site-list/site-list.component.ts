import { Component, OnInit } from '@angular/core';
import { PasswordManagerService } from '../password-manager.service';
import { Observable } from 'rxjs';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-site-list',
  templateUrl: './site-list.component.html',
  styleUrls: ['./site-list.component.css']
})
export class SiteListComponent implements OnInit {

  allSites!: Observable<Array<any>>;

  alertType: 'success' | 'error' = 'success';

  siteName!: string;
  siteURL!: string;
  siteImgURL!: string;
  siteId!: string;


  formState: string ="Add New";

  isSuccess:boolean = false;
  successMessage!:string;

  constructor(private passwordManagerService: PasswordManagerService, private route: ActivatedRoute){
    this.loadSites();
  }
  ngOnInit(): void {
    // Get query parameters from the route
    this.route.queryParams.subscribe(params => {
      this.siteId = params['siteId'] || '';
      this.siteName = params['siteName'] || '';
      this.siteURL = params['siteURL'] || '';
      this.siteImgURL = params['siteImgURL'] || '';
      this.formState = params['formState'] || 'Add New';
    });
  }

  showAlert(message:string, type: 'success' | 'error' = 'success'){
    this.isSuccess=true;
    this.successMessage=message;
    this.alertType = type;
  }

  dismissSuccessMessage() {
    this.isSuccess = false;
  }
  
  resetForm(){
    this.siteName='';
    this.siteURL='';
    this.siteImgURL='';
    this.formState='Add New';
    this.siteId='';
  }
  

  onSubmit(values: object) {
  if(this.siteName && this.siteURL && this.siteImgURL){
    if (this.formState === "Add New") {
      this.passwordManagerService.addSite(values)
        .then(() => {
          this.showAlert('Data saved successfully');
          this.resetForm();
        })
        .catch(err => {
          console.log(err);
        });
    } else if (this.formState === "Edit") {
      this.passwordManagerService.updateSite(this.siteId, values)
        .then(() => {
          this.showAlert('Data edited successfully');
          this.resetForm();
        })
        .catch(err => {
          console.log(err);
        });
    }
  }
  if (!this.siteName || !this.siteURL || !this.siteImgURL) {
    this.showAlert('All fields are required', 'error');
    return;
  }
  }
  
  loadSites() {
    this.allSites = this.passwordManagerService.loadSites();
  }


  }
