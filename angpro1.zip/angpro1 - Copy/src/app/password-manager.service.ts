import { Injectable } from '@angular/core';
import { Firestore, collection, addDoc, collectionData, doc, updateDoc, deleteDoc, setDoc } from '@angular/fire/firestore';
import { Auth, signInWithEmailAndPassword } from '@angular/fire/auth';
import { AuthCredential, EmailAuthProvider, User, createUserWithEmailAndPassword, sendEmailVerification, updateEmail, updatePassword, updateProfile} from 'firebase/auth';
import { reauthenticateWithCredential } from "firebase/auth";
import { Observable, from } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class PasswordManagerService {


  [x: string]: any;

  private isLoading: boolean = false;

  setLoading(isLoading: boolean): void {
    this.isLoading = isLoading;
  }

  getLoading(): boolean {
    return this.isLoading;
  }

  constructor(private firestore: Firestore, private auth: Auth){
    this.auth.onAuthStateChanged((user) => {
      if (user && user.emailVerified) {
        console.log('Email address successfully verified.');
        // Additional logic if needed
      } else {
        console.log('Email address not yet verified.');
      }
    });
  }
  
  addSite(data: object) {
    const user = this.auth.currentUser;

    if (!user) {
      return Promise.reject(new Error('User not authenticated'));
    }

    console.log('Adding site:', data);
    const dbInstance = collection(this.firestore, `users/${user.displayName}/sites`);
    return addDoc(dbInstance, data);
  }
  
  loadSites():Observable<any[]>{
    const user = this.auth.currentUser;

    if (!user) {
      console.log('User not authenticated');
      return new Observable<any[]>(observer => observer.next([]));
    }
    const dbInstance = collection(this.firestore, `users/${user.displayName}/sites`);
    return collectionData(dbInstance, {idField: 'id'})
  }
  updateSite(id: string, data: object){
    const user = this.auth.currentUser;

    if (!user) {
      return Promise.reject(new Error('User not authenticated'));
    }
    const docInstance = doc(this.firestore, `users/${user.displayName}/sites`, id);
    return updateDoc(docInstance, data);
  }
  deleteSite(id: string){
    const user = this.auth.currentUser;

    if (!user) {
      return Promise.reject(new Error('User not authenticated'));
    }
    const docInstance = doc(this.firestore, `users/${user.displayName}/sites`, id);
    return deleteDoc(docInstance);
  }

  //password queries

  addPassword(data: object, siteId: string){
    const user = this.auth.currentUser;

    if (!user) {
      return Promise.reject(new Error('User not authenticated'));
    }
    const dbInstance = collection(this.firestore, `users/${user.displayName}/sites/${siteId}/passwords`);
    return addDoc(dbInstance, data);
  }

  loadPasswords(siteId: string): Observable<any[]>{
    const user = this.auth.currentUser;

    if (!user) {
      return from(Promise.reject(new Error('User not authenticated')));
    }
    const dbInstance = collection(this.firestore, `users/${user.displayName}/sites/${siteId}/passwords`);
    return collectionData(dbInstance, {idField: 'id'});
  }

  updatePassword(siteId: string, passwordId: string, data:object){
    const user = this.auth.currentUser;

    if (!user) {
      return Promise.reject(new Error('User not authenticated'));
    }
    const docInstance = doc(this.firestore, `users/${user.displayName}/sites/${siteId}/passwords`, passwordId);
    return updateDoc(docInstance, data);
  }
  
  deletePassword(siteId: string, passwordId: string){
    const user = this.auth.currentUser;

    if (!user) {
      return Promise.reject(new Error('User not authenticated'));
    }
    const docInstance = doc(this.firestore, `users/${user.displayName}/sites/${siteId}/passwords`, passwordId);
    return deleteDoc(docInstance);
  }

  // login

  login(email: string, password: string){
    return signInWithEmailAndPassword(this.auth, email, password);
  }

  signup(email: string, password: string) {
    const defaultUsername = 'username';
    return createUserWithEmailAndPassword(this.auth, email, password)
    .then((userCredential) => {

      // Create a user document in Firestore with the username as the document ID
      const userDocRef = doc(this.firestore, 'users', defaultUsername);

      setDoc(userDocRef, {
        
      });

      return userCredential;
    });
  }  

  
  //get email and password

  getCurrentUser(): Promise<User | null> {
    return new Promise((resolve) => {
      this.auth.onAuthStateChanged((user) => {
        resolve(user);
      });
    });
  }

  async getUserEmail(): Promise<string | null> {
    try {
      const user = await this.getCurrentUser();
      return user ? user.email : null;
    } catch (error) {
      console.error('Error getting user email:', error);
      return null;
    }
  }

  getCurrentUserDisplayName(): string {
    const user = this.auth.currentUser;
    return user ? user.displayName || 'Guest' : 'Guest';
  }

  async changeEmail(newEmail: string): Promise<void> {
    const user = this.auth.currentUser;

    if (user && user.emailVerified) {
      console.log('Email address is already verified.');
      // Additional logic if needed
    } else {
      console.log('Email address is not verified.');
    }
  
    if (!user) {
      return Promise.reject(new Error('User not authenticated'));
    }
  
    try {
      const userEmail = await this.getUserEmail();
  
      if (userEmail === null || userEmail === newEmail) {
        return Promise.reject(new Error('Invalid email'));
      }
  
      if (!user.emailVerified) {
        await sendEmailVerification(user);
        console.log('email sent');
        const isEmailVerified = window.confirm('A verification email has been sent. Please verify your email before continuing.');
        await user.reload(); 
        await user.getIdToken(true);
        console.log('verified');

        if (!isEmailVerified) {
          console.log('not email verified');
        }
      }

      console.log('out of verification');
      
      const credential = await this.promptForCredentials(userEmail);
  
      if (!credential) {
        return Promise.reject(new Error('Credentials not provided'));
      }
      
      console.log('before reauth');
      
      await reauthenticateWithCredential(user, credential);
      console.log('after reauth');
      
  
      try {

        await updateEmail(user, newEmail);
        console.log('update method executed');
        await user.reload(); 
        await user.getIdToken(true);
        console.log('update method reloaded');
        await sendEmailVerification(user);
        console.log('send email executed');

        await this.auth.signOut();
        
      } catch (error) {
        console.error('Error updating email in Firebase Authentication:', error);
        return Promise.reject(error);
      }
    } catch (error) {
      console.error('Error updating email:', error);
      return Promise.reject(error);
    }
  }
  
  
  async changePassword(newPassword: string): Promise<void> {
    const user = this.auth.currentUser;
  
    if (!user) {
      return Promise.reject(new Error('User not authenticated'));
    }

    try {
      const userEmail = await this.getUserEmail();

      if (userEmail === null) {
        return Promise.reject(new Error('Invalid Email'));
      }
  
      if (!user.emailVerified) {
        await sendEmailVerification(user);
        console.log('email sent');
        const isEmailVerified = window.confirm('A verification email has been sent. Please verify your email before continuing.');
        await user.reload(); 
        await user.getIdToken(true);
        console.log('verified');

        if (!isEmailVerified) {
          console.log('not email verified');
        }
      }

      console.log('out of verification');
      
      const credential = await this.promptForCredentials(userEmail);
  
      if (!credential) {
        return Promise.reject(new Error('Credentials not provided'));
      }
      
      console.log('before reauth');
      
      await reauthenticateWithCredential(user, credential);
      console.log('after reauth');
      
  
      try {

        await updatePassword(user, newPassword);
        console.log('update method executed');
        await user.reload(); 
        await user.getIdToken(true);
        console.log('update method reloaded');

        await this.auth.signOut();
  
      } catch (error) {
        console.error('Error updating password in Firebase Authentication:', error);
        return Promise.reject(error);
      }
    } catch (error) {
      console.error('Error updating password:', error);
      return Promise.reject(error);
    }
}

private promptForCredentials = async (email: string): Promise<AuthCredential | null> => {
  const password = window.prompt('Enter your password:');

  if (!password) { 
    return null;
  }
  return EmailAuthProvider.credential(email, password);
};

// Inside PasswordManagerService
updateUsername(newUsername: string): Promise<void> {
  const user = this.auth.currentUser;

  if (!user) {
    return Promise.reject(new Error('User not authenticated'));
  }

  const userDocRef = doc(this.firestore, 'users', user.uid);

  return updateDoc(userDocRef, {
    username: newUsername
  });
}

}
