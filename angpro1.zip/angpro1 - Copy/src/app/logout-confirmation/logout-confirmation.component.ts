import { Component } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';

@Component({
  selector: 'app-logout-confirmation',
  templateUrl: './logout-confirmation.component.html',
  styleUrl: './logout-confirmation.component.css'
})
export class LogoutConfirmationComponent {

  constructor(private dialogRef: MatDialogRef<LogoutConfirmationComponent>) {}

  confirmLogout(): void {
    // Perform logout logic here
    // Redirect to the login page or trigger logout action
    // ...

    // Close the dialog
    this.dialogRef.close(true);
  }

  cancelLogout(): void {
    // Close the dialog without performing logout
    this.dialogRef.close(false);
  }

}
