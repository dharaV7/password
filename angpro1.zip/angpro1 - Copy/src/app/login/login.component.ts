import { Component } from '@angular/core';
import { PasswordManagerService } from '../password-manager.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {

  emailError: boolean = false;
  passwordError: boolean = false;

  isError:boolean=false;
  email!:any;
  isLoginSuccess:boolean=false;
  isSignUp: boolean = false;
  isSignupSuccess: boolean = false;
  isEmptyFieldsError: boolean = false;

  constructor(private passwordManagerService:PasswordManagerService, private router: Router){}

  onSubmit(values: any) {

    if (!values.email || !values.password) {
      this.isEmptyFieldsError = true;
      if (!values.email) {
        this.emailError = true;
      }
      if (!values.password) {
        this.passwordError = true;
      }
      return;
    }
    if (this.isSignUp) {
      this.passwordManagerService.signup(values.email, values.password)
        .then(() => {
          this.isSignupSuccess = true;
          setTimeout(() => {
            this.router.navigate(['/site-list']);
          }, 3000);
        })
        .catch(err => {
          this.isError = true;
        });
    } else {
      // Handle login logic here
      this.passwordManagerService.login(values.email, values.password)
        .then(() => {
          this.isLoginSuccess = true;
          setTimeout(() => {
            this.router.navigate(['/site-list']);
          }, 3000);
        })
        .catch(err => {
          this.isError = true;
        });
    }
    
    this.isEmptyFieldsError = false;
    this.emailError = false; 
    this.passwordError = false; 
  }

  toggleSignup(f:any) {
    this.emailError = false;
    this.passwordError = false;
    this.isError = false;
    this.isEmptyFieldsError = false;
    this.isSignUp = !this.isSignUp;

    const passwordControl = f.controls['password'];

  passwordControl.setErrors(null);

  passwordControl.setValue('');  
  passwordControl.markAsPristine();
  passwordControl.markAsUntouched();

  const emailControl = f.controls['email'];

  emailControl.setErrors(null);
  emailControl.setValue('');  
  emailControl.markAsPristine();
  emailControl.markAsUntouched();
  }

}
