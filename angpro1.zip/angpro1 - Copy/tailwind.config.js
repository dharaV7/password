/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./src/**/*.{html,js}"],
  theme: {
    extend: {
      backgroundColor:{
        'indigo-lighter': '#b3bcf5',
      }
    },
  },
  plugins: [
    require("tailwindcss-animate"),
  ],
}
